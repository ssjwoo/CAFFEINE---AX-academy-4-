from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import os

from ..db.database import get_db
from ..db.models import User

# ============================================================
# JWT 설정
# ============================================================
# SECRET_KEY: JWT 토큰 서명에 사용되는 비밀키 (절대 노출되면 안됨!)
# ALGORITHM: JWT 토큰 암호화 알고리즘 (HS256 = HMAC with SHA-256)
# ACCESS_TOKEN_EXPIRE_MINUTES: 토큰 유효 시간 (100분)
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-this")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 100

# ============================================================
# 비밀번호 암호화 설정
# ============================================================
# Passlib의 CryptContext를 사용하여 bcrypt 알고리즘으로 비밀번호를 해싱
# bcrypt: 느린 해싱 알고리즘 (무차별 대입 공격 방어에 유리)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# ============================================================
# HTTP Bearer 토큰 인증 스키마
# ============================================================
# FastAPI의 HTTPBearer를 사용하여 Authorization 헤더에서 토큰을 자동 추출
# 클라이언트는 "Authorization: Bearer {token}" 형식으로 요청
security = HTTPBearer()

# ============================================================
# 비밀번호 검증 함수
# ============================================================
def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    평문 비밀번호와 해시된 비밀번호를 비교하여 일치 여부 확인
    
    Args:
        plain_password: 사용자가 입력한 평문 비밀번호
        hashed_password: DB에 저장된 해시된 비밀번호
        
    Returns:
        bool: 비밀번호 일치 여부 (True/False)
        
    동작 원리:
        1. bcrypt.verify()를 사용하여 평문과 해시 비교
        2. bcrypt는 salt(랜덤 값)를 자동으로 처리
        3. 같은 비밀번호라도 매번 다른 해시가 생성되지만 검증은 가능
    """
    return pwd_context.verify(plain_password, hashed_password)

# ============================================================
# 비밀번호 해싱 함수
# ============================================================
def get_password_hash(password: str) -> str:
    """
    평문 비밀번호를 bcrypt로 해싱하여 안전하게 저장 가능한 형태로 변환
    
    Args:
        password: 사용자가 입력한 평문 비밀번호
        
    Returns:
        str: bcrypt로 해싱된 비밀번호 (DB 저장용)
        
    보안 특징:
        - 같은 비밀번호도 매번 다른 해시 생성 (salt 때문)
        - 단방향 암호화: 해시에서 원본 복원 불가능
        - 느린 속도: 무차별 대입 공격 방어
    """
    return pwd_context.hash(password)

# ============================================================
# JWT Access Token 생성 함수
# ============================================================
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """
    사용자 정보를 담은 JWT Access Token을 생성
    
    Args:
        data: 토큰에 포함할 데이터 (보통 {"sub": user_id} 형태)
        expires_delta: 토큰 유효 시간 (None이면 기본값 사용)
        
    Returns:
        str: 인코딩된 JWT 토큰 문자열
        
    JWT 구조:
        - Header: 알고리즘 정보 (HS256)
        - Payload: 사용자 데이터 + 만료 시간
        - Signature: SECRET_KEY로 서명 (위조 방지)
        
    예시:
        토큰 = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjEyMywiZXhwIjoxNjQwOTk1MjAwfQ.abc123..."
        디코딩하면: {"sub": 123, "exp": 1640995200, "alg": "HS256", "typ": "JWT"}
    """
    # 원본 데이터를 복사 (원본 변경 방지)
    to_encode = data.copy()
    
    # 만료 시간 계산
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    # Payload에 만료 시간 추가 ("exp" 클레임)
    to_encode.update({"exp": expire})
    
    # JWT 토큰 생성 및 인코딩
    # SECRET_KEY로 서명하여 위조 불가능하게 만듦
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# ============================================================
# 현재 로그인한 사용자 조회 (JWT 검증)
# ============================================================
def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """
    HTTP Authorization 헤더에서 JWT 토큰을 추출하고 검증하여 현재 사용자 반환
    
    FastAPI의 Dependency Injection을 사용한 인증 체인:
        1. HTTPBearer가 "Authorization: Bearer {token}" 헤더에서 토큰 추출
        2. jwt.decode()로 토큰 검증 및 Payload 추출
        3. Payload의 "sub" (subject) 필드에서 user_id 획득
        4. DB에서 user_id로 사용자 조회
        5. 사용자 객체를 반환 (또는 인증 실패 시 401 에러)
    
    Args:
        credentials: HTTPBearer가 자동으로 주입하는 인증 정보
        db: get_db()가 자동으로 주입하는 DB 세션
        
    Returns:
        User: 인증된 사용자 객체
        
    Raises:
        HTTPException(401): 토큰이 유효하지 않거나 사용자를 찾을 수 없는 경우
        
    사용 예시:
        @app.get("/protected")
        def protected_route(user: User = Depends(get_current_user)):
            return f"Hello {user.name}"
    """
    # 인증 실패 시 반환할 예외
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},  # 클라이언트에게 Bearer 토큰 요구
    )
    
    try:
        # 1. HTTPBearer가 추출한 토큰 가져오기
        token = credentials.credentials
        
        # 2. JWT 토큰 디코딩 및 검증
        #    - SECRET_KEY가 일치해야 함 (위조 방지)
        #    - 만료 시간(exp) 자동 확인
        #    - 알고리즘(ALGORITHM) 일치 확인
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        
        # 3. Payload에서 user_id 추출 ("sub" 클레임)
        user_id: int = payload.get("sub")
        if user_id is None:
            raise credentials_exception
            
    except JWTError:
        # JWT 검증 실패 (만료, 서명 불일치, 형식 오류 등)
        raise credentials_exception
    
    # 4. DB에서 사용자 조회
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        # 토큰은 유효하지만 사용자가 DB에 없음 (삭제된 계정 등)
        raise credentials_exception
        
    return user

# ============================================================
# 활성화된 사용자만 허용 (비활성 계정 차단)
# ============================================================
def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    """
    현재 사용자가 활성 상태(is_active=True)인지 확인
    
    Dependency Chain:
        get_current_user -> get_current_active_user
        (JWT 검증)        (활성 여부 확인)
    
    Args:
        current_user: get_current_user()가 주입한 사용자 객체
        
    Returns:
        User: 활성화된 사용자 객체
        
    Raises:
        HTTPException(400): 사용자가 비활성 상태인 경우
        
    사용 예시:
        @app.get("/dashboard")
        def dashboard(user: User = Depends(get_current_active_user)):
            # 이 함수는 활성화된 사용자만 접근 가능
            return {"message": f"Welcome {user.name}"}
    """
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

# ============================================================
# 관리자 권한 확인 (Admin만 접근 가능)
# ============================================================
def require_admin(current_user: User = Depends(get_current_active_user)) -> User:
    """
    현재 사용자가 관리자(role="admin")인지 확인
    
    Dependency Chain:
        get_current_user -> get_current_active_user -> require_admin
        (JWT 검증)        (활성 여부)                (관리자 여부)
    
    Args:
        current_user: get_current_active_user()가 주입한 활성 사용자
        
    Returns:
        User: 관리자 사용자 객체
        
    Raises:
        HTTPException(403): 사용자가 관리자가 아닌 경우
        
    사용 예시:
        @app.get("/admin/users")
        def admin_users(admin: User = Depends(require_admin)):
            # 이 함수는 관리자만 접근 가능
            return get_all_users()
    """
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user
