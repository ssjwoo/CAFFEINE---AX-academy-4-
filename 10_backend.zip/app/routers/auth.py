from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..db.database import get_db
from ..db.models import User
from ..db.schemas import LoginRequest, TokenResponse, UserCreate, UserOut, Message, RefreshRequest, ResetPasswordRequest
from ..core.auth import verify_password, get_password_hash, create_access_token

router = APIRouter()

@router.post("/login", response_model=TokenResponse, summary="로그인")
def login(request: LoginRequest, db: Session = Depends(get_db)):
    """사용자 로그인 및 JWT 토큰 발급"""
    user = db.query(User).filter(User.email == request.email).first()
    if not user or not verify_password(request.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password"
        )
    
    access_token = create_access_token(data={"sub": user.id})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@router.post("/refresh", response_model=TokenResponse, summary="토큰 갱신")
def refresh_token(request: RefreshRequest, db: Session = Depends(get_db)):
    """Access Token 갱신"""
    # 실제로는 refresh token 검증 로직 필요
    raise HTTPException(status_code=501, detail="Not implemented yet")

@router.post("/logout", response_model=Message, summary="로그아웃")
def logout():
    """로그아웃 (클라이언트에서 토큰 삭제)"""
    return {"message": "Successfully logged out", "success": True}

@router.post("/reset-password", response_model=Message, summary="비밀번호 재설정")
def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    """비밀번호 재설정 요청"""
    user = db.query(User).filter(User.email == request.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.hashed_password = get_password_hash(request.new_password)
    db.commit()
    
    return {"message": "Password reset successfully", "success": True}
