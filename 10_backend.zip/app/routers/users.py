from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from ..db.database import get_db
from ..db.models import User
from ..db.schemas import UserCreate, UserOut, UserDetail, UserUpdate, PasswordChange, Message
from ..core.auth import get_password_hash, verify_password, get_current_active_user, require_admin

router = APIRouter()

@router.get("", response_model=List[UserOut], summary="사용자 목록 조회 (관리자전용)")
def get_users(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """전체 사용자 목록 조회 (관리자 전용)"""
    users = db.query(User).offset(skip).limit(limit).all()
    return users

@router.get("/{user_id}", response_model=UserDetail, summary="특정 사용자 조회")
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """특정 사용자 상세 정보 조회"""
    # 본인 또는 관리자만 조회 가능
    if current_user.id != user_id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Access denied")
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.get("/me/profile", response_model=UserDetail, summary="내 정보 조회")
def get_my_profile(current_user: User = Depends(get_current_active_user)):
    """현재 로그인한 사용자 정보 조회"""
    return current_user

@router.put("/me", response_model=UserOut, summary="내 정보 수정")
def update_me(
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """현재 사용자 정보 수정"""
    if user_update.name is not None:
        current_user.name = user_update.name
    if user_update.email is not None:
        # 이메일 중복 체크
        existing = db.query(User).filter(User.email == user_update.email, User.id != current_user.id).first()
        if existing:
            raise HTTPException(status_code=400, detail="Email already exists")
        current_user.email = user_update.email
    
    db.commit()
    db.refresh(current_user)
    return current_user

@router.put("/password", response_model=Message, summary="비밀번호 변경")
def change_password(
    password_change: PasswordChange,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """사용자 비밀번호 변경"""
    if not verify_password(password_change.old_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect old password")
    
    current_user.hashed_password = get_password_hash(password_change.new_password)
    db.commit()
    
    return {"message": "Password changed successfully", "success": True}

@router.delete("/me", response_model=Message, summary="계정 삭제")
def delete_me(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """현재 사용자 계정 삭제 (비활성화)"""
    current_user.is_active = False
    db.commit()
    return {"message": "Account deleted successfully", "success": True}
