from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from typing import List, Optional
from datetime import datetime, timedelta

from ..db.database import get_db
from ..db.models import Transaction, User
from ..db.schemas import TransactionCreate, TransactionOut, TransactionUpdate, TransactionList, Message, Stats
from ..core.auth import get_current_active_user

router = APIRouter()

# ============================================================
# 거래 목록 조회 (페이지네이션 + 필터링 + 검색)
# ============================================================
@router.get("", response_model=TransactionList, summary="거래 목록 조회")
def get_transactions(
    # Query 파라미터 설정
    # ge=1: greater than or equal (1 이상만 허용)
    # le=100: less than or equal (100 이하만 허용)
    page: int = Query(1, ge=1, description="페이지 번호 (1부터 시작)"),
    limit: int = Query(20, ge=1, le=100, description="페이지당 항목 수 (최대 100)"),
    
    # Optional 필터 파라미터들
    search: Optional[str] = Query(None, description="검색어 (가맹점명, 메모)"),
    category: Optional[str] = Query(None, description="카테고리 필터"),
    card_type: Optional[str] = Query(None, description="카드 타입 필터 (신용/체크)"),
    start_date: Optional[datetime] = Query(None, description="시작 날짜"),
    end_date: Optional[datetime] = Query(None, description="종료 날짜"),
    
    # Dependency Injection
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    사용자의 거래 목록을 조회하는 엔드포인트
    
    기능:
        1. 페이지네이션: 대량의 데이터를 페이지 단위로 나눠서 조회
        2. 검색: 가맹점명 또는 메모에서 키워드 검색
        3. 필터링: 카테고리, 카드타입, 날짜 범위로 필터
        4. 정렬: 최신 거래가 먼저 오도록 날짜 내림차순 정렬
        
    Query Parameters:
        page: 페이지 번호 (1, 2, 3, ...)
        limit: 한 페이지에 표시할 항목 수
        search: 검색어 (선택사항)
        category: 카테고리 필터 (선택사항)
        card_type: 카드 타입 필터 (선택사항)
        start_date: 시작 날짜 (선택사항)
        end_date: 종료 날짜 (선택사항)
        
    Returns:
        TransactionList: {
            transactions: 거래 목록,
            total: 전체 거래 수,
            page: 현재 페이지,
            total_pages: 전체 페이지 수
        }
        
    예시 요청:
        GET /transactions?page=1&limit=20&category=식비&search=스타벅스
        => 식비 카테고리 중 "스타벅스"가 포함된 거래를 20개씩 1페이지
    """
    # ============================================================
    # 1. 기본 쿼리 생성 (현재 사용자의 거래만)
    # ============================================================
    # SQLAlchemy의 Query 객체 생성
    # 다른 사용자의 거래는 볼 수 없도록 user_id 필터 적용
    query = db.query(Transaction).filter(Transaction.user_id == current_user.id)
    
    # ============================================================
    # 2. 검색 조건 추가 (선택적)
    # ============================================================
    if search:
        # ilike: 대소문자 구분 없는 LIKE 검색 (PostgreSQL)
        # %{search}%: 앞뒤로 어떤 문자가 와도 OK
        # |: OR 조건 (merchant 또는 notes에서 검색)
        query = query.filter(
            (Transaction.merchant.ilike(f"%{search}%")) |  # 가맹점명에서 검색
            (Transaction.notes.ilike(f"%{search}%"))       # 메모에서 검색
        )
    
    # ============================================================
    # 3. 필터 조건 추가 (선택적)
    # ============================================================
    # 카테고리 필터 (정확히 일치)
    if category:
        query = query.filter(Transaction.category == category)
    
    # 카드 타입 필터 (신용/체크)
    if card_type:
        query = query.filter(Transaction.card_type == card_type)
    
    # 날짜 범위 필터
    if start_date:
        query = query.filter(Transaction.date >= start_date)  # 시작일 이후
    if end_date:
        query = query.filter(Transaction.date <= end_date)    # 종료일 이전
    
    # ============================================================
    # 4. 전체 개수 계산 (페이지네이션을 위해 필요)
    # ============================================================
    # count(): SQL의 COUNT(*) 와 동일
    # 필터가 적용된 상태에서의 전체 개수를 반환
    total = query.count()
    
    # ============================================================
    # 5. 페이지네이션 적용
    # ============================================================
    # skip: 건너뛸 항목 수 계산
    # 예: page=3, limit=20 -> skip=40 (1~40번 건너뛰고 41번부터)
    skip = (page - 1) * limit
    
    # order_by(desc(...)): 날짜 내림차순 정렬 (최신순)
    # offset(skip): skip개 건너뛰기
    # limit(limit): limit개만 가져오기
    # .all(): 실제 DB 쿼리 실행 및 결과 반환
    transactions = query.order_by(desc(Transaction.date)).offset(skip).limit(limit).all()
    
    # ============================================================
    # 6. 전체 페이지 수 계산
    # ============================================================
    # 올림 나눗셈: (total + limit - 1) // limit
    # 예: total=95, limit=20 -> total_pages=5
    total_pages = (total + limit - 1) // limit
    
    # ============================================================
    # 7. 결과 반환
    # ============================================================
    return {
        "transactions": transactions,  # 현재 페이지의 거래 목록
        "total": total,                # 전체 거래 수 (필터 적용 후)
        "page": page,                  # 현재 페이지 번호
        "total_pages": total_pages     # 전체 페이지 수
    }

@router.get("/{transaction_id}", response_model=TransactionOut, summary="거래 상세 조회")
def get_transaction(
    transaction_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """특정 거래 상세 정보 조회"""
    transaction = db.query(Transaction).filter(
        Transaction.id == transaction_id,
        Transaction.user_id == current_user.id
    ).first()
    
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    return transaction

@router.post("", response_model=TransactionOut, summary="거래 등록")
def create_transaction(
    transaction: TransactionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """새 거래 등록"""
    db_transaction = Transaction(
        **transaction.dict(),
        user_id=current_user.id
    )
    db.add(db_transaction)
    db.commit()
    db.refresh(db_transaction)
    return db_transaction

@router.put("/{transaction_id}", response_model=TransactionOut, summary="거래 수정")
def update_transaction(
    transaction_id: int,
    transaction_update: TransactionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """거래 정보 수정"""
    transaction = db.query(Transaction).filter(
        Transaction.id == transaction_id,
        Transaction.user_id == current_user.id
    ).first()
    
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    update_data = transaction_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(transaction, field, value)
    
    db.commit()
    db.refresh(transaction)
    return transaction

@router.delete("/{transaction_id}", response_model=Message, summary="거래 삭제")
def delete_transaction(
    transaction_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """거래 삭제"""
    transaction = db.query(Transaction).filter(
        Transaction.id == transaction_id,
        Transaction.user_id == current_user.id
    ).first()
    
    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")
    
    db.delete(transaction)
    db.commit()
    
    return {"message": "Transaction deleted successfully", "success": True}

@router.get("/stats", response_model=Stats, summary="거래 통계 (기간별)")
def get_transaction_stats(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """특정 기간의 거래 통계"""
    if not start_date:
        start_date = datetime.now() - timedelta(days=30)
    if not end_date:
        end_date = datetime.now()
    
    query = db.query(Transaction).filter(
        Transaction.user_id == current_user.id,
        Transaction.date >= start_date,
        Transaction.date <= end_date
    )
    
    total_transactions = query.count()
    total_spending = query.with_entities(func.sum(Transaction.amount)).scalar() or 0
    average_amount = total_spending / total_transactions if total_transactions > 0 else 0
    
    return {
        "total_spending": total_spending,
        "total_transactions": total_transactions,
        "average_amount": average_amount
    }

@router.get("/month/{year}/{month}", response_model=List[TransactionOut], summary="월별 거래 조회")
def get_monthly_transactions(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """특정 월의 모든 거래 조회"""
    # 해당 월의 시작과 끝
    start = datetime(year, month, 1)
    if month == 12:
        end = datetime(year + 1, 1, 1)
    else:
        end = datetime(year, month + 1, 1)
    
    transactions = db.query(Transaction).filter(
        Transaction.user_id == current_user.id,
        Transaction.date >= start,
        Transaction.date < end
    ).order_by(desc(Transaction.date)).all()
    
    return transactions

# ============================================================
# Top 가맹점 조회 (집계 쿼리)
# ============================================================
@router.get("/top-merchants", response_model=List[dict], summary="가맹점별 Top 10")
def get_top_merchants(
    limit: int = Query(10, le=20, description="조회할 가맹점 수 (최대 20)"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    지출 금액이 가장 많은 가맹점 순위 조회
    
    집계 쿼리(Aggregation Query):
        - GROUP BY: merchant로 그룹화
        - SUM: 가맹점별 총 지출 금액 계산
        - COUNT: 가맹점별 거래 횟수 계산
        - ORDER BY: 총액 내림차순 정렬
        
    SQL 예시:
        SELECT 
            merchant,
            SUM(amount) as total_amount,
            COUNT(id) as count
        FROM transactions
        WHERE user_id = 123
        GROUP BY merchant
        ORDER BY total_amount DESC
        LIMIT 10
        
    Returns:
        [
            {
                "merchant": "스타벅스",
                "total_amount": 150000,
                "count": 10
            },
            ...
        ]
    """
    # ============================================================
    # 집계 쿼리 작성
    # ============================================================
    # func.sum(): SQL의 SUM() 집계 함수
    # func.count(): SQL의 COUNT() 집계 함수
    # .label(): 결과 컬럼의 별칭 지정 (AS total_amount)
    results = db.query(
        Transaction.merchant,                              # 가맹점명
        func.sum(Transaction.amount).label("total_amount"), # 총 지출액
        func.count(Transaction.id).label("count")          # 거래 횟수
    ).filter(
        Transaction.user_id == current_user.id  # 현재 사용자의 거래만
    ).group_by(
        Transaction.merchant  # 가맹점별로 그룹화
    ).order_by(
        desc("total_amount")  # 총액 내림차순 정렬
    ).limit(limit).all()      # 상위 N개만
    
    # ============================================================
    # 결과를 딕셔너리 리스트로 변환
    # ============================================================
    # results는 tuple의 리스트: [(merchant, total, count), ...]
    # 이를 dict 형태로 변환하여 반환
    return [
        {
            "merchant": r.merchant,
            "total_amount": r.total_amount,
            "count": r.count
        }
        for r in results
    ]
