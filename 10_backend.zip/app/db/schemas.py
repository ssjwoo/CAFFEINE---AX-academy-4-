from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional, List

# ============ Auth Schemas ============
class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"

class RefreshRequest(BaseModel):
    refresh_token: str

class ResetPasswordRequest(BaseModel):
    email: EmailStr
    new_password: str

# ============ User Schemas ============
class UserBase(BaseModel):
    email: EmailStr
    name: str

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None

class UserOut(UserBase):
    id: int
    created_at: datetime
    is_active: bool
    role: str
    
    class Config:
        from_attributes = True

class UserDetail(UserOut):
    updated_at: datetime

class PasswordChange(BaseModel):
    old_password: str
    new_password: str

# ============ Transaction Schemas ============
class TransactionBase(BaseModel):
    merchant: str
    business_name: Optional[str] = None
    amount: float
    category: str
    date: datetime
    notes: Optional[str] = None
    card_type: Optional[str] = None
    accumulated: Optional[float] = None
    balance: Optional[float] = None

class TransactionCreate(TransactionBase):
    pass

class TransactionUpdate(BaseModel):
    notes: Optional[str] = None
    category: Optional[str] = None

class TransactionOut(TransactionBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class TransactionList(BaseModel):
    transactions: List[TransactionOut]
    total: int
    page: int
    total_pages: int

# ============ Response Schemas ============
class Message(BaseModel):
    message: str
    success: bool = True

class Stats(BaseModel):
    total_spending: float
    total_transactions: int
    average_amount: float
