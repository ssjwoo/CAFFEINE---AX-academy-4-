from .database import Base, engine, get_db
from .models import User, Transaction

# Create all tables
def init_db():
    Base.metadata.create_all(bind=engine)
