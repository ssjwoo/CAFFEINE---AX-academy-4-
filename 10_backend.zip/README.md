# Caffeine Backend API

FastAPI 기반의 금융 관리 앱 백엔드 서버

## 📋 구현된 기능

### ✅ 핵심 API (19개 엔드포인트)

#### 🔐 Auth API (4개)
- `POST /auth/login` - 로그인 및 JWT 토큰 발급
- `POST /auth/refresh` - Access Token 갱신
- `POST /auth/logout` - 로그아웃
- `POST /auth/reset-password` - 비밀번호 재설정

#### 👤 Users API (6개)
- `GET /users` - 사용자 목록 조회 (관리자 전용)
- `GET /users/{user_id}` - 특정 사용자 상세 조회
- `GET /users/me/profile` - 내 정보 조회
- `PUT /users/me` - 내 정보 수정
- `PUT /users/password` - 비밀번호 변경
- `DELETE /users/me` - 계정 삭제 (비활성화)

#### 💳 Transactions API (9개)
- `GET /transactions` - 거래 목록 조회 (페이지네이션, 검색, 필터)
- `GET /transactions/{id}` - 거래 상세 조회
- `POST /transactions` - 거래 등록
- `PUT /transactions/{id}` - 거래 수정
- `DELETE /transactions/{id}` - 거래 삭제
- `GET /transactions/stats` - 거래 통계
- `GET /transactions/month/{year}/{month}` - 월별 거래 조회
- `GET /transactions/top-merchants` - 지출 Top 가맹점

## 🛠️ 기술 스택

- **Framework**: FastAPI 0.104.1
- **Database**: PostgreSQL + SQLAlchemy 2.0
- **Authentication**: JWT (python-jose)
- **Password**: bcrypt (passlib)
- **Rate Limiting**: slowapi
- **Validation**: Pydantic 2.5

## 🚀 빠른 시작

### 1. 의존성 설치

```bash
pip install -r requirements.txt
```

### 2. 환경 변수 설정

```bash
cp .env.example .env
```

`.env` 파일 수정:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/caffeine
SECRET_KEY=your-secret-key-here-change-in-production
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:19006
```

### 3. 데이터베이스 초기화

```bash
python init_db.py
```

샘플 데이터를 생성하려면 프롬프트에서 'y' 입력

**생성되는 계정:**
- 관리자: `admin@caffeine.com` / `admin123`
- 사용자: `user@caffeine.com` / `user123`

### 4. 서버 실행

```bash
uvicorn app.main:app --reload
```

서버가 http://localhost:8000 에서 실행됩니다.

## 📚 API 문서

서버 실행 후 다음 URL에서 API 문서 확인:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🔐 보안 기능

### 구현된 보안 기능 (v1.0)
- ✅ JWT 기반 인증 (Bearer Token)
- ✅ bcrypt 비밀번호 해싱
- ✅ Role 기반 접근 제어 (user/admin)
- ✅ Rate Limiting (slowapi)
- ✅ 보안 헤더 (XSS, Clickjacking 방지)
- ✅ Audit 로그 (파일 기반)
- ✅ CORS 설정

### 향후 추가 예정 (v2.0+)
- ⏳ JWT 블랙리스트 (토큰 리보크)
- ⏳ Redis 캐싱
- ⏳ DB 기반 Audit 시스템
- ⏳ 2FA (Two-Factor Authentication)

## 📁 프로젝트 구조

```
10_backend/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI 앱 진입점
│   ├── core/                # 핵심 유틸리티
│   │   ├── __init__.py
│   │   └── auth.py          # JWT 인증, 비밀번호 해싱
│   ├── db/                  # 데이터베이스
│   │   ├── __init__.py
│   │   ├── database.py      # DB 연결 설정
│   │   ├── models.py        # SQLAlchemy 모델
│   │   └── schemas.py       # Pydantic 스키마
│   ├── routers/             # API 라우터
│   │   ├── __init__.py
│   │   ├── auth.py          # 인증 API
│   │   ├── users.py         # 사용자 API
│   │   └── transactions.py  # 거래 API
│   └── services/            # 비즈니스 로직 (추후 추가)
├── init_db.py               # DB 초기화 스크립트
├── requirements.txt         # 의존성
├── .env.example            # 환경 변수 예시
└── README.md               # 이 파일
```

## 🧪 API 사용 예시

### 1. 로그인

```bash
curl -X POST "http://localhost:8000/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@caffeine.com",
    "password": "user123"
  }'
```

**응답:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user": {
    "id": 2,
    "email": "user@caffeine.com",
    "name": "홍길동",
    "role": "user"
  }
}
```

### 2. 거래 목록 조회 (인증 필요)

```bash
curl -X GET "http://localhost:8000/transactions?page=1&limit=10" \
  -H "Authorization: Bearer {your_access_token}"
```

### 3. 거래 등록

```bash
curl -X POST "http://localhost:8000/transactions" \
  -H "Authorization: Bearer {your_access_token}" \
  -H "Content-Type: application/json" \
  -d '{
    "merchant": "스타벅스",
    "amount": 15000,
    "category": "식비",
    "date": "2024-12-03T10:00:00",
    "card_type": "신용"
  }'
```

## 🔧 개발 가이드

### 새로운 API 엔드포인트 추가하기

1. **라우터 생성** (`app/routers/new_router.py`):
```python
from fastapi import APIRouter, Depends
from ..core.auth import get_current_active_user
from ..db.database import get_db

router = APIRouter()

@router.get("/")
def get_items(current_user = Depends(get_current_active_user)):
    return {"message": "Hello"}
```

2. **main.py에 등록**:
```python
from app.routers import new_router

app.include_router(new_router.router, prefix="/items", tags=["Items"])
```

### 데이터베이스 모델 수정

1. `app/db/models.py`에서 모델 수정
2. Alembic 마이그레이션 생성 (추후 설정)
3. 마이그레이션 적용

## 📊 로그 확인

Audit 로그는 `audit.log` 파일에 기록됩니다:

```bash
tail -f audit.log
```

## 🐛 문제 해결

### PostgreSQL 연결 오류
```bash
# PostgreSQL이 실행 중인지 확인
psql -U postgres

# 데이터베이스 생성
CREATE DATABASE caffeine;
```

### Import 오류
```bash
# Python 경로 확인
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
```

## 📝 다음 단계

- [ ] 나머지 API 구현 (Predictions, Anomalies, Coupons 등)
- [ ] 단위 테스트 작성 (pytest)
- [ ] Alembic 마이그레이션 설정
- [ ] Docker 컨테이너화
- [ ] CI/CD 파이프라인 구축

## 📄 라이선스

MIT License

## 👥 기여

이슈나 PR은 언제든 환영합니다!
