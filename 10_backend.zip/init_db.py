"""
Database initialization script
데이터베이스 테이블 생성 및 초기 데이터 삽입
"""
from app.db.database import engine
from app.db.models import Base, User, Transaction
from app.core.auth import get_password_hash
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import random

def init_db():
    """
    데이터베이스 테이블 생성
    """
    print("📦 Creating database tables...")
    Base.metadata.create_all(bind=engine)
    print("✅ Database tables created successfully!")

def create_sample_data():
    """
    테스트용 샘플 데이터 생성
    """
    from app.db.database import SessionLocal
    db = SessionLocal()
    
    try:
        print("👤 Creating sample users...")
        
        # 관리자 계정
        admin = User(
            email="admin@caffeine.com",
            name="관리자",
            hashed_password=get_password_hash("admin123"),
            role="admin",
            is_active=True
        )
        db.add(admin)
        
        # 일반 사용자 계정
        user = User(
            email="user@caffeine.com",
            name="홍길동",
            hashed_password=get_password_hash("user123"),
            role="user",
            is_active=True
        )
        db.add(user)
        
        db.commit()
        db.refresh(user)
        
        print("✅ Sample users created!")
        print("   - admin@caffeine.com / admin123 (관리자)")
        print("   - user@caffeine.com / user123 (일반 사용자)")
        
        # 샘플 거래 데이터
        print("💳 Creating sample transactions...")
        
        categories = ['식비', '교통', '쇼핑', '문화', '의료']
        merchants = {
            '식비': ['스타벅스', '맥도날드', '서브웨이', '버거킹'],
            '교통': ['지하철', '버스', '택시', 'KTX'],
            '쇼핑': ['이마트', 'GS25', '다이소', '올리브영'],
            '문화': ['CGV', '왓챠', '넷플릭스', '멜론'],
            '의료': ['○○약국', '△△병원', '□□한의원']
        }
        
        # 최근 30일간의 거래 생성
        for i in range(50):
            category = random.choice(categories)
            merchant = random.choice(merchants[category])
            amount = random.randint(5, 100) * 1000  # 5천원 ~ 10만원
            
            transaction = Transaction(
                user_id=user.id,
                merchant=merchant,
                business_name=f"{merchant}(주)",
                amount=amount,
                category=category,
                date=datetime.now() - timedelta(days=random.randint(0, 30)),
                card_type=random.choice(['신용', '체크']),
                notes=f"{merchant}에서 구매" if random.random() > 0.7 else None
            )
            db.add(transaction)
        
        db.commit()
        print(f"✅ Created 50 sample transactions!")
        
    except Exception as e:
        print(f"❌ Error creating sample data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 Caffeine Database Initialization")
    print("=" * 60)
    
    init_db()
    
    response = input("\n📝 Create sample data? (y/n): ")
    if response.lower() == 'y':
        create_sample_data()
    
    print("\n" + "=" * 60)
    print("✅ Database initialization completed!")
    print("=" * 60)
